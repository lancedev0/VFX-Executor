﻿script_key="lzRAbGvvGxOvuFTQdMBoSSRNLosrfjUG";
loadstring(game:HttpGet("https://raw.githubusercontent.com/smi9/UnnamedCheats/refs/heads/main/loader.lua"))();